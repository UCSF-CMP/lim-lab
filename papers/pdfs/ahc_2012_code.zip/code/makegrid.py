#! /usr/bin/python

#$ -S /usr/bin/python
#$ -o /netapp/home/angichau/logs/
#$ -e /netapp/home/angichau/err/
#$ -l xe5520=true
#$ -l arch=lx24-amd64
#$ -l mem_free=3G
#$ -l h_rt=0:30:00
#$ -t 1-3


# this script generates the sampling grid, using Latin-hypercube sampling

import os
import math
import random

def generateSamples(low, high, number, logbase):
    points = [0]*number

    for i in xrange(number):
        if (i%10000 == 0):
            print i
            
        leftSide = low + i*(high-low)/math.floor(number)
        rightSide = low + (i+1)*(high-low)/math.floor(number)
        r = random.uniform(leftSide,rightSide)
        if (logbase == 0):
            points[i] =  r
        else:
            points[i] = pow(10, r)
            
    random.shuffle(points)
    return(points)

# ------

allpoints = [10000]
program = 'newDlog'

print os.getenv('HOSTNAME')
t = int(os.getenv('SGE_TASK_ID'))-1

if (t == 0):
    names = ['AAs', 'BAs', 'CAs', 'ABs', 'BBs', 'CBs', 'ACs','BCs','CCs']
    lobound = 0
    upbound = 4
    logged = 1
elif (t==1):
    names = ['NA','NB','NC']
    lobound = 0
    upbound = 4
    logged = 0
elif (t==2):
    names = ['diffAs','diffBs','diffCs']
    lobound = -2
    upbound = 2
    logged = 1


for gridPoints in allpoints:
    for var in names: 
        nums = generateSamples(lobound, upbound, gridPoints, logged)
        out = open('samples/'+program+'/'+var+'_'+str(gridPoints)+'.txt','w')
        out.write(' '.join(['%.5f'%x for x in nums]))
        out.close()
        
        
