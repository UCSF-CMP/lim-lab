#! /usr/bin/python

# this module contains all the functions needed for running simulations and are
# called by the master scripts 

import re
import math
import shutil
import os
import time
import tempfile
print os.getenv('HOSTNAME')
import numpy as np
import random

# ----------------------------------------------------------------------
# RUN ONE GROUP
# runs all the simulations for one parameter file and processes the results
# 
def runOneGroup(program, trialnum, paramFile, scratchDir, homeDir, saveAll, savekymo, prepol):
    
    print os.getenv('HOSTNAME')
    print time.strftime('TIME %d %b, %X', time.localtime())    
    print 'reading ' + paramFile

    # make temp directory
    tempDir = tempfile.mkdtemp(dir=scratchDir)
    print tempDir
    
    # ---------- read in param file -----------
    params = open(paramFile,'r')
    numbers = re.compile(r'([-\d.]+)')

    # first line has the global settings for this run
    line = params.readline()
    settings = [int(n) for n in numbers.findall(line)]
    totalSteps = settings[0]
    size = settings[1]
    topology = settings[2]
    startingIndex = settings[3]
    currCircuitIndex = startingIndex
    maxSimTime = settings[4]
    
    # read all the rest of the lines as just strings first
    allLines = []
    line = params.readline()
    while (line):
        allLines.append(line)
        line = params.readline()
    params.close()
        
    # -------- run each set of params ------------
    # summary and scores will be saved in one file 
    resultsPrefix = tempDir + '/top' + str(topology) + '_' + \
        str(startingIndex) + '.' + str(trialnum)
    kymoPrefix = tempDir + '/top' + str(topology) + '_'
    
    for oneLine in allLines:  
        
        oneset = [float(n) for n in numbers.findall(oneLine)]
        (na, nb, nc) = [int(n) for n in oneset[0:3]]
        (basea, baseb, basec, aoff, boff, coff, ha, hb, hc) = oneset[3:12]
        (da, db, dc) = oneset[12:15]
        (aa, ba, ca, ab, bb, cb, ac, bc, cc) = oneset[15:]
        
        # this is the list of params to pass to the simulation
        paramList= [totalSteps,size,na,nb,nc,aa,ba,ca,ab,bb,cb,ac,bc,cc,basea,baseb,basec,aoff,boff,coff,ha,hb,hc,da,db,dc,savekymo,prepol,maxSimTime]
    
        # this is where the data file will be saved for processing
        tempFile = tempDir + '/c' + str(currCircuitIndex) + '.' + str(trialnum)
        
        # run simulation using OS
        print program + ' ' + ' '.join(['%.5f'%x for x in paramList]) \
            + ' > ' + tempFile
        os.system(program + ' ' + ' '.join(['%.5f'%x for x in paramList]) \
                      + ' > ' + tempFile)
        
        # analyze the data and record scores
        status = summarizeSimulation(currCircuitIndex, tempFile, resultsPrefix, kymoPrefix, saveAll)
        
        # since the data files are huge, clean them up as we go along
        os.remove(tempFile)
        
        print time.strftime('TIME %d %b, %X', time.localtime())
        
        currCircuitIndex += 1

    os.system('cp ' + resultsPrefix + '* ' + homeDir)

    try:
        os.mkdir(homeDir + 'top'+str(topology)+'_kymos/')
    except OSError:
        print "directory already made"

    os.system('cp ' + kymoPrefix + '*kymo* ' + homeDir + 'top'+str(topology)+'_kymos/')
    os.system('cp ' + kymoPrefix + '*.ss* ' + homeDir + 'top'+str(topology)+'_kymos/')
    os.system('cp ' + kymoPrefix + '*.dir* ' + homeDir + 'top'+str(topology)+'_kymos/')
    shutil.rmtree(tempDir)

    print time.strftime('TIME %d %b, %X', time.localtime())

# ----------------------------------------------------------------------
# SUMMARIZE SIMULATION
# each run of a polarity simulation will save out a text file with
# the data from all timepoints. 

def summarizeSimulation(index, infile, prefix, kymoPrefix, saveAll):

    POINTS = 50
    
    numbers = re.compile(r'([-\d.]+)')
    results = re.compile(r'i(\d+) t([\d.]+) a(\d+) b(\d+) c(\d+) ma([-\d.]+) da([\d.]+) mb([-\d.]+) db([\d.]+) mc([-\d.]+) dc([\d.]+) K\{([^}]*)\}')
    saveIt = False;
    
    kymo1fn = kymoPrefix + str(index) + '.kymo.in.gz'
    kymo2fn = kymoPrefix + str(index) + '.kymo.re.gz'
    scorefile = prefix + '.score'
    
    print '\textracting data from ' + infile
    f = open(infile, 'r')
    
    # parse first line = SETTINGS
    line = f.readline()
    settings = [float(n) for n in numbers.findall(line)]
    (latSize, na, nb, nc) = [int(n) for n in settings[0:4]]
    (aa, ba, ca, ab, bb, cb, ac, bc, cc) = settings[4:13]
    (basea, baseb, basec) = settings[13:16]
    (aoff, boff, coff) = settings[16:19]
    (ha, hb, hc) = settings[19:22]
    (da, db, dc) = settings[22:]
    paramList= [index,na,nb,nc,aa,ba,ca,ab,bb,cb,ac,bc,cc,basea,baseb,basec,aoff,boff,coff,ha,hb,hc,da,db,dc]
    
    # ************** PARSE INITIAL RESULTS ********************   
    magA1 = []
    dirA1 = []
    magB1 = []
    dirB1 = []
    magC1 = []
    dirC1 =[]
    kymo1 = []
    hasKymo1 = False

    stillReading = True
    ssReached = -99    # if this is -99, then something went wrong
    killed = -99
    
    while (stillReading):    
        line = f.readline()
        data = results.findall(line)   # data is a bunch of tuples
        ss = re.findall('^9999$', line)    
        notss = re.findall('^0000$', line)    

        if (data):
            numbers = [float(n) for n in data[0][0:11]]
            magA1.append(numbers[5])
            dirA1.append(numbers[6])
            magB1.append(numbers[7])
            dirB1.append(numbers[8])
            magC1.append(numbers[9])
            dirC1.append(numbers[10])
            snap = data[0][11]
            if (snap):
                hasKymo1 = True
                kymo1.append(np.array(np.fromstring(snap,dtype=int,sep=',')))
        else:
            stillReading = False
            line = f.readline()
            stopped = re.findall('^KILLED$', line)
            notstopped = re.findall('^FINE$', line)
            
            if (ss):
                ssReached = numbers[0]
                print '\tINITSS'
            if (notss) :
                ssReached = 0
                
            if (stopped):
                killed = numbers[0]   # saves the # steps completed if killed
                print '\tKILLED'
            if (notstopped):
                killed = 0
                
    if ((saveAll==1) or ((np.mean(magA1[-POINTS:]) > 0.5) and (ss) and (hasKymo1))):
        saveIt = True

    nowrap = dirA1[-POINTS:]
    wrap = np.array(nowrap)
    wrap[np.where(wrap>180)] = wrap[np.where(wrap>180)]-360
    A1mean = np.mean(nowrap)
    if (np.std(wrap) < np.std(nowrap)):
        A1mean = np.mean(wrap)
    if (A1mean < 0):
        A1mean = A1mean + 360

    nowrap = dirB1[-POINTS:]
    wrap = np.array(nowrap)
    wrap[np.where(wrap>180)] = wrap[np.where(wrap>180)]-360
    B1mean = np.mean(nowrap)
    if (np.std(wrap) < np.std(nowrap)):
        B1mean = np.mean(wrap)
    if (B1mean < 0):        
        B1mean = B1mean + 360

    nowrap = dirC1[-POINTS:]
    wrap = np.array(nowrap)
    wrap[np.where(wrap>180)] = wrap[np.where(wrap>180)]-360
    C1mean = np.mean(nowrap)
    if (np.std(wrap) < np.std(nowrap)):
        C1mean = np.mean(wrap)
    if (C1mean < 0):
        C1mean = C1mean + 360        
        
    initResults = str(ssReached) + ' ' + str(killed) + ' ' + ' '.join('%.2f'%x for x in [numbers[1], np.mean(magA1[-POINTS:]), A1mean, np.mean(magB1[-POINTS:]), B1mean, np.mean(magC1[-POINTS:]), C1mean])
    
    # ************** PARSE REORIENT RESULTS ********************
    # NOTE: This is no longer used
    reorient = False
    reorientResults = ''

    # ************** SAVE TO FILES ********************
    out = open(scorefile, 'a')
    out.write(' '.join(['%.5f'%x for x in paramList]) + ' ' + initResults + ' ' + reorientResults)
    out.write('\n')
    out.close()

    # SAVE KYMOS TO FILES
    if (saveIt and hasKymo1):
        np.savetxt(kymo1fn, kymo1, '%d', ' ');

    return reorient
