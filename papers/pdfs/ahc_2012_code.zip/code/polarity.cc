// -----------------------------------------------------------------------------
// Coarse-grained stochastic lattice model for cell polarity
//
// (Requires the GSL library)
//
// FOR:
// "Designing synthetic regulatory networks capable of self-organizing cell polarization."
// Chau AH, Walter JM, Gerardin J, Tang C, Lim WA.
// Cell. 2012 Oct 12;151(2):320-32. 
//
// Note: this simulation code was written to allow for as many as 3 components in the
// regulatory networks although we only used 2 in the above Cell paper.
//
// Author: Angela Chau
// Date: Apr 2011
// -----------------------------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <gsl/gsl_rng.h>

// constants for determining steady-state
#define EQUIL 100        // at least run for this many steps

#define THRESHOLD 0.8    // if correlations are higher than this
#define STEADYOVER 50    // for this many consecutive steps, then steady-state!

#define INPUT_AREA 0.1   // sharpness of stimulus input, if present
#define M 1              // # of binding sites per lattice location

const double PI = atan(1.0)*4;

time_t starttime;
gsl_rng* r;
long steps;
double *IA, *IB, *IC;
int *As, *Bs, *Cs;
int Acyto, Bcyto, Ccyto;
int Amem, Bmem, Cmem;
int stimLocation;
double simTime;
double minRateConstant;
double maxSimTime;
double maxRateConstant;

// these will always be pointing to current center of mass for each component
double thisXA, thisYA, maxMag;
double thisXB, thisYB;
double thisXC, thisYC;

double *rxnRates;
double *rates_Aon, *rates_Aoff, *rates_Bon, *rates_Boff, *rates_Con, *rates_Coff;

// settings that are passed in by user
int L;
int totalAs, totalBs, totalCs;
double AA, BA, CA, AB, BB, CB, AC, BC, CC;
double Aon, Bon, Con;
double Aoff, Boff, Coff;
double stimA, stimB, stimC;
double Da, Db, Dc;
int savekymo, prepolarize;

int counter;
double* prevLattice;

void setupGrid(int mode);
void setupInitial(int mode);
void updateMetrics();
void updateRateTables();

// --------------------------------------------------------------------------------
// INITIALIZE EVERYTHING

void start()
{
  // seed the random number generator
  starttime = time(NULL);
  const gsl_rng_type* Typ;
  gsl_rng_env_setup();
  Typ = gsl_rng_default;
  r = gsl_rng_alloc(Typ);
  gsl_rng_set(r, starttime);

  // initialize everything
  steps = 0;
  simTime = 0;  
  thisXA = 0.;
  thisYA = 0.;
  thisXB = 0.;
  thisYB = 0.;
  thisXC = 0.;
  thisYC = 0.;
  maxMag = -1;

  // minRateConstant used to determine when to count off a
  // simulation step
  minRateConstant = 100000;
  if ((Da > 0) && (Da < minRateConstant))
    minRateConstant = Da;
  if ((Db > 0) && (Db < minRateConstant))
    minRateConstant = Db;
  if ((Dc > 0) && (Dc < minRateConstant))
    minRateConstant = Dc;
  
  maxRateConstant = 0;

  // keeps track of total # of components on membrane vs cytosol
  Amem = 0;
  Bmem = 0;
  Cmem = 0;
  Acyto = totalAs;
  Bcyto = totalBs;
  Ccyto = totalCs;

  IA = new double[L]; 
  IB = new double[L];
  IC = new double[L];
  setupGrid(0);
  
  As = new int[L];
  Bs = new int[L];
  Cs = new int[L];
  prevLattice = new double[L];

  // used during simulation as giant array of rates
  rxnRates = new double[L*9]; // 3 binding rxn, 3 dissoc, 3 diffusion
			      // per site

  // the base rates (before multiplying by concentrations)
  rates_Aon = new double[L];
  rates_Aoff = new double[L];
  rates_Bon = new double[L];
  rates_Boff = new double[L];
  rates_Con = new double[L];
  rates_Coff = new double[L];

  for (int x=0; x<L; x++) {
    As[x] = 0;
    Bs[x] = 0;
    Cs[x] = 0;

    if ((x < L/4) && (prepolarize == 1)) {
      As[x] = 1;
      thisXA += cos(x*2.*PI/L);
      thisYA += sin(x*2.*PI/L);
    } 

    rates_Aon[x] = Aon;
    rates_Aoff[x] = Aoff;
    rates_Bon[x] = Bon;
    rates_Boff[x] = Boff;
    rates_Con[x] = Con;
    rates_Coff[x] = Coff;

    prevLattice[x] = (As[x]-0.5)*2;
  }

  counter = 0;
}

void cleanup()   // free up all allocated memory!!
{
  delete [] IA;
  delete [] IB;
  delete [] IC;
  delete [] As;
  delete [] Bs;
  delete [] Cs;

  delete [] rxnRates;
  delete [] rates_Aon;
  delete [] rates_Aoff;
  delete [] rates_Bon;
  delete [] rates_Boff;
  delete [] rates_Con;
  delete [] rates_Coff;

  delete [] prevLattice;

  gsl_rng_free(r);
}


// --------------------------------------------------------------------------------
// SETTING UP

double gauss(int x, double sc, double sx)
{
  return sc*exp(-1*(pow(x/sx,2)));
}

// sets up stimulus field (uniform or point source) -- optional
void setupGrid(int mode)
{
  int xx;
  
  for (int x=0; x<L; x++) {

    if (mode == 0) { // point source at N/4    
      if (x > L*3/4)  {
	xx = (x-L);
      } else  {
	xx = x;
      }      
      xx = xx-L/4;
      stimLocation = L/4;
      
    } else if (mode == 1) { // point source at 3N/4
      if (x < L/4) {
	xx = x+L;
      } else  {
	xx = x;
      }
      xx = xx-L*3/4;      
      stimLocation = 3*L/4;
    }
    
    if (stimA < 0) {
      IA[x] = -stimA;
    } else {
      IA[x] = gauss(xx, stimA, 1.0*L*INPUT_AREA);
    }
    if ((Aon+IA[x] > 0.0001) && (Aon+IA[x] < minRateConstant))
      minRateConstant = Aon + IA[x];
    if ((Aoff-IA[x] > 0.0001) && (Aoff-IA[x] < minRateConstant))
      minRateConstant = Aoff - IA[x];
    
    if (stimB < 0) {
      IB[x] = -stimB;
    } else {
      IB[x] = gauss(xx, stimB, 1.0*L*INPUT_AREA);
    }
    if ((Bon+IB[x] > 0.0001) && (Bon+IB[x] < minRateConstant))
      minRateConstant = Bon + IB[x];
    if ((Boff-IB[x] > 0.0001) && (Boff-IB[x] < minRateConstant))
      minRateConstant = Boff - IB[x];

    
    if (stimC < 0) {
      IC[x] = -stimC;
    } else {	
      IC[x] = gauss(xx, stimC, 1.0*L*INPUT_AREA); 
    }
    if ((Con+IC[x] > 0.0001) && (Con+IC[x] < minRateConstant))
      minRateConstant = Con + IC[x];
    if ((Coff-IC[x] > 0.0001) && (Coff-IC[x] < minRateConstant))
      minRateConstant = Coff - IC[x];    

  }
}


//--------------------------------------------------------------------------------
// UPDATE FUNCTIONS

double countUpNeighbors(int xx, int which)
{
  int totalOcc = 0;
  int *lat;

  if (which==1) 
    lat = As;
  else if (which==2)
    lat = Bs;
  else if (which==3)
    lat = Cs;
  
  // left & right
  totalOcc += lat[(xx-1+L)%L];
  totalOcc += lat[(xx+1)%L];

  return 1.0*totalOcc;
}

void updateRateAt(int x)  // update the reaction rates at one site
{
  double na,nb,nc;
  double neighA, neighB, neighC;  // neighborhood effects

  // determine neighborhood occupancy
  na = countUpNeighbors(x,1);
  nb = countUpNeighbors(x,2);
  nc = countUpNeighbors(x,3);

  if (M > 1) {
    neighA = AA*(na+As[x])/3 + BA*(nb+Bs[x])/3 + CA*(nc+Cs[x])/3;
    neighB = AB*(na+As[x])/3 + BB*(nb+Bs[x])/3 + CB*(nc+Cs[x])/3;
    neighC = AC*(na+As[x])/3 + BC*(nb+Bs[x])/3 + CC*(nc+Cs[x])/3;
  } else {
    neighA = AA*na/2         + BA*(nb+Bs[x])/3 + CA*(nc+Cs[x])/3;
    neighB = AB*(na+As[x])/3 + BB*nb/2         + CB*(nc+Cs[x])/3;
    neighC = AC*(na+As[x])/3 + BC*(nb+Bs[x])/3 + CC*nc/2;    
  }
  
  // make sure rates don't go negative
  // also, keep track of the slowest reaction in system so far
  rates_Aon[x] = std::max(Aon + IA[x] + neighA, 0.);
  rates_Aoff[x] = std::max(Aoff - IA[x] - neighA, 0.);

  rates_Bon[x] = std::max(Bon + IB[x] + neighB, 0.);
  rates_Boff[x] = std::max(Boff - IB[x] - neighB, 0.);

  rates_Con[x] = std::max(Con + IC[x] + neighC, 0.);
  rates_Coff[x] = std::max(Coff - IC[x] - neighC, 0.);  
}

void updateAllRates()  // refresh the full rate tables
{
  for (int x=0; x<L; x++) {
    updateRateAt(x);
  }
}

int doOneUpdate()
{
  int flag = 0;
  
  // first, generate giant table of rates and running sum
  double a0 = 0;
  for (int x=0; x<L; x++) {
    rxnRates[x]     = rates_Aon[x] *1. *Acyto/L*(M-As[x]);
    rxnRates[x+1*L] = rates_Aoff[x]*1. *As[x];
    
    rxnRates[x+2*L] = rates_Bon[x] *1. *Bcyto/L*(M-Bs[x]);
    rxnRates[x+3*L] = rates_Boff[x]*1. *Bs[x];

    rxnRates[x+4*L] = rates_Con[x] *1. *Ccyto/L*(M-Cs[x]);
    rxnRates[x+5*L] = rates_Coff[x]*1. *Cs[x];

    rxnRates[x+6*L] = Da * 1.* As[x];
    rxnRates[x+7*L] = Db * 1.* Bs[x];
    rxnRates[x+8*L] = Dc * 1.* Cs[x];

    a0 += rxnRates[x]+rxnRates[x+1*L]+rxnRates[x+2*L]+rxnRates[x+3*L]+rxnRates[x+4*L]+rxnRates[x+5*L]+rxnRates[x+6*L]+rxnRates[x+7*L]+rxnRates[x+8*L];    
  }

  if (a0 > 0) {   // as long as there's some diffusion constant, this
		  // should always be true

    // figure out how long to next rxn
    double tau = -1./a0*log(gsl_rng_uniform(r));
    simTime += tau;
    
    // figure out which rxn happened
    double rn = gsl_rng_uniform(r);
    double cumsum = 0;
    int chosen = 0;  
    for (int i=0; i<L*9; i++) {
      cumsum += rxnRates[i];
      if (cumsum/a0 >= rn) {
	chosen=i;
	break;
      }
    }
    
    // perform reaction
    int event = floor(chosen/L);
    int loc = chosen%L;
    
    switch (event) {
    case 0:  // A binds
      As[loc]++;
      Amem++;
      Acyto--;
      thisXA += cos(loc*2.*PI/L);
      thisYA += sin(loc*2.*PI/L);
      break;
    case 1:  // A dissoc
      As[loc]--;
      Amem--;
      Acyto++;
      thisXA -= cos(loc*2.*PI/L);
      thisYA -= sin(loc*2.*PI/L);
      break;
    case 2:  // B binds
      Bs[loc]++;
      Bmem++;
      Bcyto--;
      thisXB += cos(loc*2.*PI/L);
      thisYB += sin(loc*2.*PI/L);
      break;
    case 3:   // B dissoc
      Bs[loc]--;
      Bmem--;
      Bcyto++;
      thisXB -= cos(loc*2.*PI/L);
      thisYB -= sin(loc*2.*PI/L);
      break;
    case 4:   // C binds
      Cs[loc]++;
      Cmem++;
      Ccyto--;
      thisXC += cos(loc*2.*PI/L);
      thisYC += sin(loc*2.*PI/L);
      break;
    case 5:   // C dissocs
      Cs[loc]--;
      Cmem--;
      Ccyto++;
      thisXC -= cos(loc*2.*PI/L);
      thisYC -= sin(loc*2.*PI/L);
      break;
    case 6:  // A diffuses
      if (gsl_rng_uniform(r) < 0.5) {
	if (As[(loc-1+L)%L] < M) {
	  As[loc]--;
	  As[(loc-1+L)%L]++;
	  thisXA -= cos(loc*2.*PI/L);
	  thisYA -= sin(loc*2.*PI/L);
	  thisXA += cos(((loc-1+L)%L)*2.*PI/L);
	  thisYA += sin(((loc-1+L)%L)*2.*PI/L);
	}
      } else {
	if (As[(loc+1)%L] < M) {
	  As[loc]--;
	  As[(loc+1)%L]++;
	  thisXA -= cos(loc*2.*PI/L);
	  thisYA -= sin(loc*2.*PI/L);
	  thisXA+= cos(((loc+1)%L)*2.*PI/L);
	  thisYA += sin(((loc+1)%L)*2.*PI/L);
	}
      }
      break;    
    case 7:  // B diffuses
      if (gsl_rng_uniform(r) < 0.5) {
	if (Bs[(loc-1+L)%L] < M) {
	  Bs[loc]--;
	  Bs[(loc-1+L)%L]++;
	  thisXB -= cos(loc*2.*PI/L);
	  thisYB -= sin(loc*2.*PI/L);
	  thisXB += cos(((loc-1+L)%L)*2.*PI/L);
	  thisYB += sin(((loc-1+L)%L)*2.*PI/L);
	}
      } else {
	if (Bs[(loc+1)%L] < M) {
	  Bs[loc]--;
	  Bs[(loc+1)%L]++;
	  thisXB -= cos(loc*2.*PI/L);
	  thisYB -= sin(loc*2.*PI/L);
	  thisXB += cos(((loc+1)%L)*2.*PI/L);
	  thisYB += sin(((loc+1)%L)*2.*PI/L);
	}
      }
      break;
    case 8:  // C diffuses
      if (gsl_rng_uniform(r) < 0.5) {
	if (Cs[(loc-1+L)%L] < M) {
	  Cs[loc]--;	
	  Cs[(loc-1+L)%L]++;
	  thisXC -= cos(loc*2.*PI/L);
	  thisYC -= sin(loc*2.*PI/L);
	  thisXC += cos(((loc-1+L)%L)*2.*PI/L);
	  thisYC += sin(((loc-1+L)%L)*2.*PI/L);
	}
      } else {
	if (Cs[(loc+1)%L] < M) {
	  Cs[loc]--;
	  Cs[(loc+1)%L]++;
	  thisXC -= cos(loc*2.*PI/L);
	  thisYC -= sin(loc*2.*PI/L);
	  thisXC += cos(((loc+1)%L)*2.*PI/L);
	  thisYC += sin(((loc+1)%L)*2.*PI/L);
	}
      }
      break;
    }
    
    // update rate tables with neighbor effects
    // since each location depends on nearest neighbors and we might
    // have diffused to a neighbor, will have to update ratss for at most 5 sites
    int x1;
    for (int delta=-2; delta<=2; delta++) {
      x1 = (loc+delta+L)%L;
      updateRateAt(x1);
    }   
  } else {
    flag = -1;    // all probs went to zero, so nothing's going to
		  // happen now
    // this won't happen as long as there is some slow rate of diffusion
  }

  return flag; 
}

int doOneStep()
{
  int flag = 0;
  
  long int howlong = 0;
  double nextStopTime = steps*1./minRateConstant; 

  while ((flag==0) && (simTime < nextStopTime)) {
    doOneUpdate();
    howlong++;

    // if total simulation time has exceeded maximum, kill the simulation
    if (difftime(time(NULL), starttime) > maxSimTime) {
      flag = -1;
    }
  }         
  return flag;   

}

//--------------------------------------------------------------------------------
// CHECK FOR STEADY STATE

int checkAutoStop() {

  int flag = 0;

  // correlate A lattice between time steps
  double corr = 0;
  for (int x=0; x<L; x++) {
    corr += prevLattice[x] * (As[x]-0.5)*2;    
    prevLattice[x] = (As[x]-0.5)*2;
  }

  // requires that correlation is high for a certain # of steps
  if (corr/100 >= THRESHOLD)
    counter++;
  else
    counter = 0;
  
  if (counter > STEADYOVER)
    flag = 1;

  return flag;
}


//--------------------------------------------------------------------------------

void printMetrics()
{
  // maximum magnitude occurs when lattice is half full  
  if (maxMag < 0) {
    double tempX = 0.;
    double tempY = 0.;
    maxMag = 0.;
    
    for (int x=0; x<L/2; x++) {
      tempX += M*cos(x*2.*PI/L);
      tempY += M*sin(x*2.*PI/L);
    }
    maxMag = sqrt(tempX*tempX + tempY*tempY);
  }
  
  double directionA = atan2(thisYA, thisXA)*180/PI;
  if (directionA < 0)
    directionA += 360;
  double magnitudeA = sqrt(thisXA*thisXA + thisYA*thisYA)/maxMag;

  double directionB = atan2(thisYB, thisXB)*180/PI;
  if (directionB < 0)
    directionB += 360;
  double magnitudeB = sqrt(thisXB*thisXB + thisYB*thisYB)/maxMag;

  double directionC = atan2(thisYC, thisXC)*180/PI;
  if (directionC < 0)
    directionC += 360;
  double magnitudeC = sqrt(thisXC*thisXC + thisYC*thisYC)/maxMag;
  
  printf("i%ld t%.3f a%d b%d c%d ma%.2f da%.2f mb%.2f db%.2f mc%.2f dc%.2f",
	 steps, simTime, Amem, Bmem, Cmem, magnitudeA, directionA, 
	 magnitudeB, directionB, magnitudeC, directionC);

  printf(" K{");
  if (savekymo) {
    for (int x=0; x<L; x++) {
      if (M == 1) 
	printf("%d,", As[x]+Bs[x]*2+Cs[x]*4);
      else
	printf("%d,", As[x]);
    }
  }
  printf("} \n");
}

// ********************************************************************************

int main(int argc, char** argv)
{ 
  // first, read in the settings for the simulation run
  if (argc < 29) {
    printf("You only passed in %d arguments: \n", argc);
    printf("gillespie <maxsteps> <size> <totAs> <totBs> <totCs> ");
    printf("<AA> <BA> <CA> <AB> <BB> <CB> <AC> <BC> <CC> ");
    printf("<Aon> <Bon> <Con> <Aoff> <Boff> <Coff> ");
    printf("<stimA> <stimB> <stimC> <diffA> <diffB> <diffC> <savekymo> <prepol> <maxSimTime>\n");
    return 1;
  }

  // set up parameters for simulation
  int i = 1;
  long totalSteps = strtol(argv[i++], NULL, 10); 
  L = atoi(argv[i++]);

  totalAs = atoi(argv[i++]);
  totalBs = atoi(argv[i++]);
  totalCs = atoi(argv[i++]);
  
  AA = atof(argv[i++]);
  BA = atof(argv[i++]);
  CA = atof(argv[i++]);
  AB = atof(argv[i++]);
  BB = atof(argv[i++]);
  CB = atof(argv[i++]);
  AC = atof(argv[i++]);
  BC = atof(argv[i++]);
  CC = atof(argv[i++]);
  
  Aon = atof(argv[i++]);
  Bon = atof(argv[i++]);
  Con = atof(argv[i++]);
  Aoff = atof(argv[i++]);
  Boff = atof(argv[i++]);
  Coff = atof(argv[i++]);

  stimA = atof(argv[i++]);
  stimB = atof(argv[i++]);
  stimC = atof(argv[i++]);
  Da = atof(argv[i++]);
  Db = atof(argv[i++]);
  Dc = atof(argv[i++]);
  savekymo = atoi(argv[i++]);
  prepolarize = atoi(argv[i++]);
  
  if (argc == 30)
    maxSimTime = atof(argv[i++]);
  else
    maxSimTime = 900;
  
  printf("%d %d %d %d ", L, totalAs, totalBs, totalCs);
  printf("%.5f %.5f %.5f ", AA, BA, CA);
  printf("%.5f %.5f %.5f ", AB, BB, CB);
  printf("%.5f %.5f %.5f ", AC, BC, CC);
  printf("%.5f %.5f %.5f ", Aon, Bon, Con);
  printf("%.5f %.5f %.5f ", Aoff, Boff, Coff);
  printf("%.5f %.5f %.5f ", stimA, stimB, stimC);
  printf("%.5f %.5f %.5f\n", Da, Db, Dc);
  
  // -----------------------------------------------------------------------------------------------------------------
  // start simulation
  
  start();
  updateAllRates(); // effectively, turn on stimulus and circuit effects

  int ssReached = 0;
  int killed;
  printMetrics();

  do {
    steps++;    
    killed = doOneStep();  // if -1, then max time exceeded 
    printMetrics();
    if ((killed==0) && (steps > EQUIL)) 
      ssReached = checkAutoStop();

  } while ((killed == 0) && (ssReached==0) && (steps < totalSteps));

  // print out flags that will be read by Python scripts later
  if (ssReached == 1)
    printf("9999\n");
  else
    printf("0000\n");

  if (killed == -1)
    printf("KILLED\n");
  else
    printf("FINE\n");  
  
  cleanup();
  return 0;
}

